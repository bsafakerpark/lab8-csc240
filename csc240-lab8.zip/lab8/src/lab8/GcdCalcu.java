package lab8;

import java.util.Scanner;

public class GcdCalcu {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter positive integer as numerator: ");
		int numerator = scanner.nextInt();
		
		System.out.print("Enter positive integer as denominator: ");
	    int denominator = scanner.nextInt();

	    if (numerator <= 0 || denominator <= 0) {
	    	System.out.println("Both numbers must be positive integers.");
	    	scanner.close();
	    	return;
	        }
	  
	    RationalNumber rationalNumber = new RationalNumber(numerator, denominator);
	    
	    int gcdValue = rationalNumber.computeGcd();
	    System.out.println("Greatest common denominator of " + numerator + "/" + denominator + " is " + gcdValue);
	    
	    scanner.close();
	    }
	}


