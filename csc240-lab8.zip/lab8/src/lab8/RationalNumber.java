package lab8;

public class RationalNumber {
	private int numerator;
	private int denominator;

public RationalNumber(int numerator, int denominator) {
	this.numerator = numerator;
	this.denominator = denominator;
	    }

public int gcd(int x, int y) {
	        if (y == 0) {
	            return x;
	        } else {
	            return gcd(y, x % y);  // Recursive: gcd(y, x % y)
	        }
	    }

	    // Method to compute the GCD 
	    public int computeGcd() {
	        return gcd(numerator, denominator);
	    }

	    // Getter methods for numerator and denominator 
	    public int getNumerator() {
	        return numerator;
	    }

	    public int getDenominator() {
	        return denominator;
	    }
	}

	



